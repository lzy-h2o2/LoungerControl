package com.LRKZ.Advice;

public class Advice_info {
private int uid;
private String uname;
private String utel;
private String uemail;
private String uadvice;
public String getUtel() {
	return utel;
}
public void setUtel(String utel) {
	this.utel = utel;
}
public int getUid() {
	return uid;
}
public void setUid(int uid) {
	this.uid = uid;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getUemail() {
	return uemail;
}
public void setUemail(String uemail) {
	this.uemail = uemail;
}
public String getUadvice() {
	return uadvice;
}
public void setUadvice(String uadvice) {
	this.uadvice = uadvice;
}
}
