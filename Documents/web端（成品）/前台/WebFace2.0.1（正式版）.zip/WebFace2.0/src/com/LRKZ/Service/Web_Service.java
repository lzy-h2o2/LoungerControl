package com.LRKZ.Service;

import java.util.List;

import com.LRKZ.AddAdvice.Add_Advice;
import com.LRKZ.Advice.Advice_info;
import com.LRKZ.Advice.Updatelog_info;

public class Web_Service {

	public String Add_adv(Advice_info advice_info){
		Add_Advice add_Advice=new Add_Advice();
		if (add_Advice.Add_ad(advice_info).equals("1")) {
			return "ok";
		}else {
			return "no";
		}
	}
	public List<Updatelog_info> All_Log(){
		Add_Advice add_Advice=new Add_Advice();
		if (add_Advice.Show_AllLog()!=null) {
			return add_Advice.Show_AllLog();
		}else {
			return null;
		}
	}
	public String Get_adr(){
		Add_Advice add_Advice=new Add_Advice();
		String address=null;
		if (add_Advice.Get_Adr()!=null) {
			address=add_Advice.Get_Adr();
		}
		return address;
	}
}
