package com.LRKZ.AddAdvice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.LRKZ.Admin_DBConn.DB_Connection;
import com.LRKZ.Advice.Advice_info;
import com.LRKZ.Advice.Updatelog_info;
import com.LRKZ.Inter.DB_inter;

public class Add_Advice implements DB_inter {

	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	
	@Override
	public String Add_ad(Advice_info advice_info) {
		// TODO Auto-generated method stub
		String sql="insert into useradvice(uname,utel,uemail,uadvice) value(?,?,?,?);";
		con=DB_Connection.getConnection();
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, advice_info.getUname());
			ps.setString(2, advice_info.getUtel());
			ps.setString(3, advice_info.getUemail());;
			ps.setString(4, advice_info.getUadvice());
			int i=ps.executeUpdate();
			if (i>0) {
				DB_Connection.Close(con, ps, rs);
				return "1";
			}else {
				DB_Connection.Close(con, ps, rs);
				return "0";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Updatelog_info> Show_AllLog() {
		// TODO Auto-generated method stub
		String sql="select * from state;";
		con=DB_Connection.getConnection();
		Updatelog_info updatelog_info=null;
		List<Updatelog_info> list=new ArrayList<Updatelog_info>();
		try {
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			while (rs.next()) {
				updatelog_info=new Updatelog_info();
				updatelog_info.setSdate(rs.getString(3));
				updatelog_info.setSintro(rs.getString(4));
				updatelog_info.setSdetail(rs.getString(5));
				list.add(updatelog_info);
			}
			DB_Connection.Close(con, ps, rs);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public String Get_Adr() {
		// TODO Auto-generated method stub
		String sql="select app from appfile ORDER BY NO DESC LIMIT 0,1;";
		String adr=null;
		con=DB_Connection.getConnection();
		try {
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			while (rs.next()) {
				adr=rs.getString(1);
			}
			DB_Connection.Close(con, ps, rs);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return adr;
	}

}
