package com.LRKZ.Inter;

import java.util.List;

import com.LRKZ.Advice.Advice_info;
import com.LRKZ.Advice.Updatelog_info;

public interface DB_inter {
    public String Add_ad(Advice_info advice_info);
    public List<Updatelog_info> Show_AllLog();
    public String Get_Adr();
}
